<template>
  <div class="user-bottom-nav">
    <div
      v-for="item in navMenu"
      :key="item.path"
      :class="['nav-item', { active: isActive(item.path) }]"
      @click="router.push(item.path)"
    >
      <div class="nav-icon-container">
        <el-icon :size="24">
          <component :is="item.icon" />
        </el-icon>
      </div>
      <span class="nav-label">{{ $t('nav.' + item.id) }}</span>
    </div>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router'
import IconHome from '@/components/icons/IconHome.vue'
import IconCategory from '@/components/icons/IconCategory.vue'
import IconPlus from '@/components/icons/IconPlus.vue'
import IconUser from '@/components/icons/IconUser.vue'

const router = useRouter()
const route = useRoute()

const navMenu = [
  { id: 'home', label: '首页', path: '/user/dashboard', icon: IconHome },
  { id: 'categories', label: '分类', path: '/user/categories', icon: IconCategory },
  { id: 'publish', label: '发布', path: '/user/publish', icon: IconPlus },
  { id: 'myAccount', label: '我的', path: '/user/profile', icon: IconUser }
]

const isActive = (path) => {
  return route.path === path || route.path.startsWith(path + '/')
}
</script>

<style scoped>
.user-bottom-nav {
  display: none;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: calc(60px + env(safe-area-inset-bottom));
  background: rgba(255, 255, 255, 0.97);
  backdrop-filter: blur(10px);
  box-shadow: 0 -1px 12px rgba(0, 0, 0, 0.08);
  z-index: 1000;
  justify-content: space-around;
  align-items: stretch;
  border-top: 1px solid rgba(0, 0, 0, 0.06);
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  color: #909399;
  flex: 1;
  cursor: pointer;
  transition: color 0.18s ease, transform 0.06s ease;
}

.nav-item:active {
  transform: scale(0.98);
}

.nav-item.active {
  color: var(--primary-color);
}

.nav-icon-container {
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.18s ease;
}

.nav-item.active .nav-icon-container {
  transform: translateY(-1px);
}

.nav-label {
  font-size: 10px;
  font-weight: 500;
  line-height: 1;
  transition: color 0.18s ease;
}

.nav-item.active .nav-label {
  color: var(--primary-color);
  font-weight: 700;
}

@media screen and (max-width: 767px) {
  .user-bottom-nav {
    display: flex;
  }
}
</style>
